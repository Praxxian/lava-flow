import LavaFlow from './lava-flow';
export class LavaFlowSettings {
	constructor() {
		this.overwrite = true;
		this.ignoreDuplicate = false;
		this.idPrefix = `${LavaFlow.ID}-`;
		this.playerObserve = false;
		this.createIndexFile = false;
		this.createBacklinks = true;
		this.importNonMarkdown = true;
		this.useS3 = false;
	}
}

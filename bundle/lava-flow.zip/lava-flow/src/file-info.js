export class FileInfo {
	constructor(file) {
		this.keys = [];
		this.directories = [];
		this.originalFile = file;
	}
	static get(file) {
		const nameParts = file.webkitRelativePath.split('.');
		const extension = nameParts[nameParts.length - 1];
		if (extension === 'md')
			return new MDFileInfo(file);
		else
			return new OtherFileInfo(file);
	}
	createKeys(fileName) {
		this.directories = this.originalFile.webkitRelativePath.split('/');
		this.directories.shift(); // Remove root folder name
		this.directories.pop(); // Remove file name
		for (let i = 0; i < this.directories.length; i++) {
			const prefixes = this.directories.slice(i);
			prefixes.push(fileName);
			this.keys.push(prefixes.join('/'));
		}
	}
	isHidden() {
		return this.originalFile.webkitRelativePath.split('/').filter((s) => s[0] === '.').length > 0;
	}
}
export class MDFileInfo extends FileInfo {
	constructor(file) {
		super(file);
		const nameParts = file.name.split('.');
		this.fileNameNoExt = nameParts[0];
		this.createKeys(this.fileNameNoExt);
	}
	getLinkRegex() {
		return this.keys.map((k) => new RegExp(`\\[\\[${k}(\\s*\\|[^\\]]*)?\\]\\]`, 'gi'));
	}
}
export class OtherFileInfo extends FileInfo {
	constructor(file) {
		super(file);
		this.createKeys(file.name);
	}
	getLinkRegex() {
		return this.keys.map((k) => new RegExp(`!\\[\\[${k}(\\s*\\|[^\\]]*)?\\]\\]`, 'gi'));
	}
}

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
	function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
	return new (P || (P = Promise))(function (resolve, reject) {
		function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
		function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
		function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
		step((generator = generator.apply(thisArg, _arguments || [])).next());
	});
};
import LavaFlow from './lava-flow';
import { LavaFlowSettings } from './lava-flow-settings';
export class LavaFlowForm extends FormApplication {
	static get defaultOptions() {
		var _a, _b;
		const defaults = super.defaultOptions;
		const overrides = {
			height: 500,
			id: `${LavaFlow.ID}-form`,
			template: LavaFlow.TEMPLATES.IMPORTDIAG,
			title: 'Import Obsidian MD Vault',
			importSettings: (_b = (_a = game === null || game === void 0 ? void 0 : game.user) === null || _a === void 0 ? void 0 : _a.getFlag(LavaFlow.FLAGS.SCOPE, LavaFlow.FLAGS.LASTSETTINGS)) !== null && _b !== void 0 ? _b : new LavaFlowSettings(),
			classes: [],
			closeOnSubmit: true,
			submitOnChange: false,
			submitOnClose: false,
			editable: true,
			baseApplication: '',
			width: 500,
			top: 0,
			left: 0,
			popOut: false,
			minimizable: false,
			resizable: false,
			dragDrop: [],
			tabs: [],
			filters: [],
			scrollY: [],
		};
		const mergedOptions = mergeObject(defaults, overrides);
		return mergedOptions;
	}
	_updateObject(event, formData) {
		return __awaiter(this, void 0, void 0, function* () {
			formData.vaultFiles = this.vaultFiles;
			yield LavaFlow.importVault(event, formData);
		});
	}
	getData(options) {
		return options.importSettings;
	}
	activateListeners(html) {
		var _a, _b, _c;
		const prefix = (_c = (_b = (_a = LavaFlowForm.defaultOptions) === null || _a === void 0 ? void 0 : _a.importSettings) === null || _b === void 0 ? void 0 : _b.idPrefix) !== null && _c !== void 0 ? _c : '';
		this.setInverseToggle(`#${prefix}overwrite`, `#${prefix}ignoreDuplicateDiv`);
		this.setToggle(`#${prefix}importNonMarkdown`, `#${prefix}nonMarkdownOptions`);
		this.setToggle(`#${prefix}useS3`, `#${prefix}s3Options`);
		const vaultFilesID = `#${prefix}vaultFiles`;
		$(vaultFilesID).on('change', (event) => {
			this.vaultFiles = event.target.files;
		});
	}
	setInverseToggle(checkBoxID, toggleDivID) {
		this.setToggle(checkBoxID, toggleDivID, true);
	}
	setToggle(checkBoxID, toggleDivID, inverse = false) {
		$(checkBoxID).change(function () {
			const checkbox = this;
			$(toggleDivID).toggle((!inverse && checkbox.checked) || (inverse && !checkbox.checked));
		});
	}
}

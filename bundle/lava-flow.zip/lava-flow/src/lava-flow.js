var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
	function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
	return new (P || (P = Promise))(function (resolve, reject) {
		function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
		function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
		function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
		step((generator = generator.apply(thisArg, _arguments || [])).next());
	});
};
var _a;
import { FileInfo, MDFileInfo, OtherFileInfo } from './file-info';
import { LavaFlowForm } from './lava-flow-form';
import { LavaFlowSettings } from './lava-flow-settings';
import { createOrGetFolder } from './util';
import { Converter } from 'showdown';
// eslint-disable-next-line @typescript-eslint/no-extraneous-class
export default class LavaFlow {
	static log(msg, notify) {
		var _b;
		console.log(LavaFlow.toLogMessage(msg));
		if (notify)
			(_b = ui === null || ui === void 0 ? void 0 : ui.notifications) === null || _b === void 0 ? void 0 : _b.info(LavaFlow.toLogMessage(msg));
	}
	static errorHandling(e) {
		var _b;
		console.error(LavaFlow.toLogMessage(e));
		(_b = ui === null || ui === void 0 ? void 0 : ui.notifications) === null || _b === void 0 ? void 0 : _b.error(LavaFlow.toLogMessage(e));
	}
	static toLogMessage(msg) {
		return `Lava Flow | ${msg}`;
	}
	static createUIElements(app, html) {
		var _b, _c;
		if (!((_c = (_b = game === null || game === void 0 ? void 0 : game.user) === null || _b === void 0 ? void 0 : _b.isGM) !== null && _c !== void 0 ? _c : false) || app.options.id !== 'journal')
			return;
		LavaFlow.log('Creating UI elements...', false);
		const className = `${LavaFlow.ID}-btn`;
		const tooltip = game.i18n.localize('LAVA-FLOW.button-label');
		const button = $(`<div class="${LavaFlow.ID}-row action-buttons flexrow"><button class="${className}"><i class="fas fa-upload"></i> ${tooltip}</button></div>`);
		button.on('click', function () {
			LavaFlow.createForm();
		});
		html.find('.directory-header').prepend(button);
		LavaFlow.log('Creating UI elements complete.', false);
	}
	static createForm() {
		var _b, _c;
		if (!((_c = (_b = game === null || game === void 0 ? void 0 : game.user) === null || _b === void 0 ? void 0 : _b.isGM) !== null && _c !== void 0 ? _c : false))
			return;
		new LavaFlowForm().render(true);
	}
	static importVault(event, settings) {
		var _b, _c;
		return __awaiter(this, void 0, void 0, function* () {
			if (!((_c = (_b = game === null || game === void 0 ? void 0 : game.user) === null || _b === void 0 ? void 0 : _b.isGM) !== null && _c !== void 0 ? _c : false))
				return;
			LavaFlow.log('Begin import...', true);
			yield this.saveSettings(settings);
			const rootFolder = yield createOrGetFolder(settings.rootFolderName);
			const files = [];
			for (let i = 0; i < settings.vaultFiles.length; i++) {
				const file = FileInfo.get(settings.vaultFiles[i]);
				if (file.isHidden())
					continue;
				yield LavaFlow.importFile(file, settings, rootFolder);
				files.push(file);
			}
			const allJournals = files.map((d) => d.journal);
			for (let i = 0; i < files.length; i++)
				yield LavaFlow.updateLinks(files[i], allJournals);
			if (settings.createIndexFile || settings.createBacklinks) {
				const mdFiles = files.filter((f) => f instanceof MDFileInfo);
				if (settings.createIndexFile)
					yield LavaFlow.createIndexFile(settings, mdFiles, rootFolder);
				if (settings.createBacklinks)
					yield LavaFlow.createBacklinks(mdFiles);
			}
			LavaFlow.log('Import complete.', true);
		});
	}
	static saveSettings(settings) {
		var _b;
		return __awaiter(this, void 0, void 0, function* () {
			const savedSettings = new LavaFlowSettings();
			Object.assign(savedSettings, settings);
			savedSettings.vaultFiles = new FileList();
			yield ((_b = game === null || game === void 0 ? void 0 : game.user) === null || _b === void 0 ? void 0 : _b.setFlag(LavaFlow.FLAGS.SCOPE, LavaFlow.FLAGS.LASTSETTINGS, savedSettings));
		});
	}
	static importFile(file, settings, rootFolder) {
		return __awaiter(this, void 0, void 0, function* () {
			if (file instanceof MDFileInfo) {
				yield this.importMarkdownFile(file, settings, rootFolder);
			}
			else if (settings.importNonMarkdown && file instanceof OtherFileInfo) {
				yield this.importOtherFile(file, settings);
			}
		});
	}
	static importMarkdownFile(file, settings, rootFolder) {
		var _b;
		return __awaiter(this, void 0, void 0, function* () {
			let parentFolder = rootFolder;
			for (let i = 0; i < file.directories.length; i++) {
				const newFolder = yield createOrGetFolder(file.directories[i], parentFolder === null || parentFolder === void 0 ? void 0 : parentFolder.id);
				parentFolder = newFolder;
			}
			const journalName = file.fileNameNoExt;
			let journal = (_b = game === null || game === void 0 ? void 0 : game.journal) === null || _b === void 0 ? void 0 : _b.find((j) => j.name === journalName && j.data.folder === (parentFolder === null || parentFolder === void 0 ? void 0 : parentFolder.id));
			if (journal == null) {
				journal = yield LavaFlow.createJournalFromFile(journalName, parentFolder, file, settings.playerObserve);
			}
			else if (settings.overwrite) {
				yield LavaFlow.updateJournalFromFile(journal, file);
			}
			else if (!settings.ignoreDuplicate) {
				yield LavaFlow.updateJournalFromFile(journal, file);
			}
			if (settings.createBacklinks) {
				const linkRegex = /(\[\[[^\]]+\]\])/g;
				const regexMatches = [...journal.data.content.matchAll(linkRegex)];
				const matches = [...new Set(regexMatches.map((m) => LavaFlow.decodeHtml(m[0])))];
				file.links = matches;
			}
			file.journal = journal;
		});
	}
	static importOtherFile(file, settings) {
		return __awaiter(this, void 0, void 0, function* () {
			const source = settings.useS3 ? 's3' : 'data';
			const body = settings.useS3 ? { bucket: settings.s3Bucket } : {};
			const promise = FilePicker.upload(source, settings.mediaFolder, file.originalFile, body);
			let path = `${settings.mediaFolder}/${file.originalFile.name}`;
			path.replace('//', '/');
			if (settings.useS3) {
				path = `https://${settings.s3Bucket}.s3.${settings.s3Region}.amazonaws.com/${path}`;
			}
			file.uploadPath = path;
			yield promise;
		});
	}
	static createIndexFile(settings, files, rootFolder) {
		var _b;
		return __awaiter(this, void 0, void 0, function* () {
			const indexJournalName = 'Index';
			const indexJournal = (_b = game === null || game === void 0 ? void 0 : game.journal) === null || _b === void 0 ? void 0 : _b.find((j) => j.name === indexJournalName && j.data.folder === (rootFolder === null || rootFolder === void 0 ? void 0 : rootFolder.id));
			const mdDictionary = files.filter((d) => d instanceof MDFileInfo);
			const directories = [...new Set(mdDictionary.map((d) => LavaFlow.getIndexTopDirectory(d)))];
			directories.sort();
			let content = '';
			for (let j = 0; j < directories.length; j++) {
				content += `<h1>${directories[j]}</h1>`;
				const journals = mdDictionary
					.filter((d) => LavaFlow.getIndexTopDirectory(d) === directories[j])
					.map((d) => d.journal);
				content += `<ul>${journals.map((j) => `<li>${j.link}</li>`).join('\n')}</ul>`;
			}
			if (indexJournal != null)
				yield LavaFlow.updateJournal(indexJournal, content);
			else {
				yield LavaFlow.createJournal(indexJournalName, rootFolder, content, settings.playerObserve);
			}
		});
	}
	static getIndexTopDirectory(fileInfo) {
		return fileInfo.directories.length > 0 ? fileInfo.directories[0] : 'Uncatergorized';
	}
	static createBacklinks(files) {
		return __awaiter(this, void 0, void 0, function* () {
			for (let i = 0; i < files.length; i++) {
				const fileInfo = files[0];
				const linkedJournals = files.filter((d) => LavaFlow.linkMatch(fileInfo, d)).map((d) => d.journal);
				if (linkedJournals.length > 0) {
					const newContent = `${fileInfo.journal.data.content}\r\n<h1>References</h1>\r\n<ul>${linkedJournals
						.map((j) => `<li>${j.link}</li>`)
						.join('\r\n')}<ul>`;
					yield LavaFlow.updateJournal(fileInfo.journal, newContent);
				}
			}
		});
	}
	static linkMatch(fileInfo, matchFileInfo) {
		if (matchFileInfo !== fileInfo && matchFileInfo instanceof MDFileInfo) {
			const linkPatterns = fileInfo.getLinkRegex();
			for (let i = 0; i < linkPatterns.length; i++) {
				if (matchFileInfo.links.filter((l) => l.match(linkPatterns[i])).length > 0)
					return true;
			}
		}
		return false;
	}
	static decodeHtml(html) {
		const txt = document.createElement('textarea');
		txt.innerHTML = html;
		return txt.value;
	}
	static createJournalFromFile(journalName, parentFolder, file, playerObserve) {
		return __awaiter(this, void 0, void 0, function* () {
			const fileContent = yield LavaFlow.getFileContent(file);
			return yield LavaFlow.createJournal(journalName, parentFolder, fileContent, playerObserve);
		});
	}
	static createJournal(journalName, parentFolder, content, playerObserve) {
		var _b;
		return __awaiter(this, void 0, void 0, function* () {
			const entryData = {
				_id: '',
				name: journalName,
				folder: parentFolder === null || parentFolder === void 0 ? void 0 : parentFolder.id,
				content,
				permission: new Permissions(),
			};
			if (playerObserve) {
				entryData.permission.default = CONST.ENTITY_PERMISSIONS.OBSERVER;
			}
			const entry = (_b = (yield JournalEntry.create(entryData))) !== null && _b !== void 0 ? _b : new JournalEntry();
			yield entry.setFlag(LavaFlow.FLAGS.SCOPE, LavaFlow.FLAGS.JOURNAL, true);
			return entry;
		});
	}
	static updateJournalFromFile(journal, file) {
		return __awaiter(this, void 0, void 0, function* () {
			yield LavaFlow.updateJournal(journal, yield LavaFlow.getFileContent(file));
		});
	}
	static updateJournal(journal, content) {
		return __awaiter(this, void 0, void 0, function* () {
			yield journal.update({ content });
		});
	}
	// TODO v10 markdown
	static getFileContent(file) {
		return __awaiter(this, void 0, void 0, function* () {
			const markdown = yield file.originalFile.text();
			const converter = new Converter({
				tables: true,
				tablesHeaderId: true,
				strikethrough: true,
				tasklists: true,
			});
			return converter.makeHtml(markdown);
		});
	}
	static updateLinks(fileInfo, allJournals) {
		return __awaiter(this, void 0, void 0, function* () {
			const linkPatterns = fileInfo.getLinkRegex();
			for (let i = 0; i < allJournals.length; i++) {
				const compareJournal = allJournals[i];
				for (let i = 0; i < linkPatterns.length; i++) {
					// todo other files use imgelement
					const newContent = compareJournal.data.content.replace(linkPatterns[i], fileInfo.journal.link);
					if (newContent !== compareJournal.data.content) {
						yield LavaFlow.updateJournal(compareJournal, newContent);
						break;
					}
				}
			}
		});
	}
}
_a = LavaFlow;
LavaFlow.ID = 'lava-flow';
LavaFlow.FLAGS = {
	FOLDER: 'lavaFlowFolder',
	JOURNAL: 'lavaFlowJournalEntry',
	SCOPE: 'world',
	LASTSETTINGS: 'lava-flow-last-settings',
};
LavaFlow.TEMPLATES = {
	IMPORTDIAG: `modules/${_a.ID}/templates/lava-flow-import.hbs`,
};

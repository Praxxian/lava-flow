# Lava Flow

## Release 2.1.0 (2022-01-21)

- Added support for resizing images
- Fixed an issue where images with alt text were not linked.
- Fixed an issue where image paths were not properly encoded.

## Release 2.0.0 (2022-09-05)

- Added changelog
- Updated codebase to Typescript
- Foundry v10 compatibility

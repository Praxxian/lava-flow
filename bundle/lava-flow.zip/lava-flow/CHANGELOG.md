# Lava Flow

## Release 2.0.0 (2022-09-05)

- Added changelog
- Updated codebase to Typescript
- Foundry v10 compatibility
